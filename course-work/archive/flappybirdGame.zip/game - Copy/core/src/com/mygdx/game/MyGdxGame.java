package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;

import java.awt.Font;
import java.util.Random;

public class MyGdxGame extends ApplicationAdapter {
//	ShapeRenderer shapeRenderer;
	Circle birdCircle;
	SpriteBatch batch;
	Texture background,startGraphic,bird[];
	Texture topTube,bottomTube;
	Texture gameOver;
	BitmapFont font,highScoreFont;
	int highScore=0;
	int flapState = 0,gameState=0,numberOfTubes=4,score=0,scoringTube=0;
	float birdY = 0,velocity =0,gap=400,maxTubeOffset,tubeVelocity=4,tubeX[]=new float[numberOfTubes],tubeOffset[]=new float[numberOfTubes],distanceBetweenTubes;
	Random random;
	Rectangle topTubeRectangles[],bottomTubeRectangles[];
	Preferences  preferences;
	@Override
	public void create () {
		preferences = Gdx.app.getPreferences("MyPreference");
		batch = new SpriteBatch();
		background = new Texture("bg.png");
		startGraphic = new Texture("startgraphic.png");
//	    shapeRenderer = new ShapeRenderer();
	    birdCircle = new Circle();
		bird= new Texture[2];
	    bird[0]=new Texture("bird.png");
		bird[1]=new Texture("bird2.png");
		topTube= new Texture("toptube.png");
		bottomTube= new Texture("bottomtube.png");
		maxTubeOffset = Gdx.graphics.getHeight()/2 - gap/2 -100;
		random=new Random();
		 distanceBetweenTubes= Gdx.graphics.getWidth()*3/4;
        topTubeRectangles=new Rectangle[numberOfTubes];
        bottomTubeRectangles=new Rectangle[numberOfTubes];
		font = new BitmapFont();
		highScoreFont = new BitmapFont();
		font.setColor(Color.WHITE);
		font.getData().setScale(10);
		highScoreFont.setColor(Color.RED);
		highScoreFont.getData().setScale(15);
		gameOver=new Texture("gameover.png");

		highScore=preferences.getInteger("highScore",0);
            if(highScore==0) {
                preferences.putInteger("highScore", 0);
                preferences.flush();
            }
		startGame();

	}

	public void startGame(){

		birdY = Gdx.graphics.getHeight() / 2 - bird[flapState].getHeight() /2;
		for(int i=0;i< numberOfTubes;++i){
			tubeOffset[i] = random.nextInt((int) gap) - gap / 2;
			tubeX[i] =Gdx.graphics.getWidth()/2- topTube.getWidth()/2 +Gdx.graphics.getWidth()  + i * distanceBetweenTubes;
			topTubeRectangles[i]=new Rectangle();
			bottomTubeRectangles[i]=new Rectangle();
		}
	}
	@Override
	public void render () {
		batch.begin();


		batch.draw(background, 0, 0,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());

		if(gameState==0)
		batch.draw(startGraphic,Gdx.graphics.getWidth()/2-startGraphic.getWidth()/2,Gdx.graphics.getHeight()/2-startGraphic.getHeight()/2);


		if(gameState==1) {
			if(tubeX[scoringTube]<Gdx.graphics.getWidth()/2){
				score++;
				if(scoringTube<numberOfTubes-1)
					scoringTube++;
				else
					scoringTube=0;
			}


			if(Gdx.input.justTouched()) {
				velocity =- 20;
			}

		for(int i=0;i< numberOfTubes;++i) {
			if(tubeX[i]<-topTube.getWidth()) {
                tubeOffset[i] = random.nextInt((int) gap) - gap / 2;
                tubeX[i] = tubeX[i] + numberOfTubes * distanceBetweenTubes;
            }
			else
            	tubeX[i] -= tubeVelocity;
            batch.draw(topTube, tubeX[i], Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffset[i]);
            batch.draw(bottomTube, tubeX[i], Gdx.graphics.getHeight() / 2 - bottomTube.getHeight() - gap / 2 + tubeOffset[i]);

            topTubeRectangles[i]=new Rectangle(tubeX[i] ,Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffset[i],topTube.getWidth(),topTube.getHeight());
			bottomTubeRectangles[i]=new Rectangle(tubeX[i] ,Gdx.graphics.getHeight() / 2 - bottomTube.getHeight() - gap / 2 + tubeOffset[i],topTube.getWidth(),topTube.getHeight());

		}
			batch.draw(bird[flapState] , Gdx.graphics.getWidth() / 2 - bird[flapState].getWidth() / 2, birdY);
			font.draw(batch,String.valueOf(score),100,200);

			if(birdY>0 ) {
				velocity++;
				birdY -= velocity;//gravity
			    }else {
                gameState = 2;
                }
		}else if(gameState==0){

			if(Gdx.input.justTouched()){
				gameState=1;
			}
		}else if(gameState==2){
			batch.draw(gameOver,Gdx.graphics.getWidth()/2-gameOver.getWidth()/2,Gdx.graphics.getHeight()/2-gameOver.getHeight()/2);
			if(highScore>=score) {
				highScoreFont.draw(batch, String.valueOf(highScore), Gdx.graphics.getWidth() / 2 - 50, Gdx.graphics.getHeight() * 3 / 4);
			}else {
				preferences.putInteger("highScore", score);
				preferences.flush();
				highScoreFont.draw(batch,String.valueOf(score),Gdx.graphics.getWidth()/2 - 50,Gdx.graphics.getHeight()*3/4);
			}

			if(Gdx.input.justTouched()){
				gameState=1;
				startGame();
				score=0;
				scoringTube=0;
				velocity=0;
			}
		}

		if (flapState == 0)
			flapState = 1;
		else
			flapState = 0;

		batch.end();

		birdCircle.set(Gdx.graphics.getWidth()/2,birdY+bird[flapState].getHeight()/2,bird[flapState].getWidth()/2);


//		shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
//		shapeRenderer.setColor(Color.RED);
//		shapeRenderer.circle(birdCircle.x,birdCircle.y,birdCircle.radius);

		for(int i =0 ;i<numberOfTubes;++i){
//			shapeRenderer.rect(tubeX[i],Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffset[i],topTube.getWidth(),topTube.getHeight());
//			shapeRenderer.rect(tubeX[i],Gdx.graphics.getHeight() / 2 - bottomTube.getHeight() - gap / 2 + tubeOffset[i],topTube.getWidth(),topTube.getHeight());

			if(Intersector.overlaps(birdCircle,topTubeRectangles[i]) || Intersector.overlaps(birdCircle,bottomTubeRectangles[i])){
				gameState=2;
			}
		}


//		shapeRenderer.end();
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		background.dispose();
	}
}
